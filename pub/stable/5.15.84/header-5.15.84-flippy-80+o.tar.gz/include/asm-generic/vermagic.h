/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef _ASM_GENERIC_VERMAGIC_H
#define _ASM_GENERIC_VERMAGIC_H

#define MODULE_ARCH_VERMAGIC ""

#endif /* _ASM_GENERIC_VERMAGIC_H */
